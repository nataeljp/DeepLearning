#  THIS IS AN R PROGRAM
#  ********************

cat("Welcome to Toby's R course\n")	#Anything between quotes (") is printed to the screen (the "\n" bit means new line)

for (x in 1:5) {
 cat(x,", ")
}
cat("\b\b stars to you for getting this far!\n")	#"\b" means backspace

#PS. Anything after a hash (#) is just a comment in an R program and the computer ignores it
